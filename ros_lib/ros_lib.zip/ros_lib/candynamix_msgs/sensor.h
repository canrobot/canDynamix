#ifndef _ROS_candynamix_msgs_sensor_h
#define _ROS_candynamix_msgs_sensor_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace candynamix_msgs
{

  class sensor : public ros::Msg
  {
    public:
      typedef int32_t _left_count_type;
      _left_count_type left_count;
      typedef int32_t _right_count_type;
      _right_count_type right_count;
      typedef uint16_t _sonic_distance_time_type;
      _sonic_distance_time_type sonic_distance_time;
      typedef int16_t _ax_type;
      _ax_type ax;
      typedef int16_t _ay_type;
      _ay_type ay;
      typedef int16_t _az_type;
      _az_type az;
      typedef int16_t _gx_type;
      _gx_type gx;
      typedef int16_t _gy_type;
      _gy_type gy;
      typedef int16_t _gz_type;
      _gz_type gz;
      typedef float _qw_type;
      _qw_type qw;
      typedef float _qx_type;
      _qx_type qx;
      typedef float _qy_type;
      _qy_type qy;
      typedef float _qz_type;
      _qz_type qz;

    sensor():
      left_count(0),
      right_count(0),
      sonic_distance_time(0),
      ax(0),
      ay(0),
      az(0),
      gx(0),
      gy(0),
      gz(0),
      qw(0),
      qx(0),
      qy(0),
      qz(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int32_t real;
        uint32_t base;
      } u_left_count;
      u_left_count.real = this->left_count;
      *(outbuffer + offset + 0) = (u_left_count.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_left_count.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_left_count.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_left_count.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->left_count);
      union {
        int32_t real;
        uint32_t base;
      } u_right_count;
      u_right_count.real = this->right_count;
      *(outbuffer + offset + 0) = (u_right_count.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_right_count.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_right_count.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_right_count.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->right_count);
      *(outbuffer + offset + 0) = (this->sonic_distance_time >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->sonic_distance_time >> (8 * 1)) & 0xFF;
      offset += sizeof(this->sonic_distance_time);
      union {
        int16_t real;
        uint16_t base;
      } u_ax;
      u_ax.real = this->ax;
      *(outbuffer + offset + 0) = (u_ax.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ax.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->ax);
      union {
        int16_t real;
        uint16_t base;
      } u_ay;
      u_ay.real = this->ay;
      *(outbuffer + offset + 0) = (u_ay.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ay.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->ay);
      union {
        int16_t real;
        uint16_t base;
      } u_az;
      u_az.real = this->az;
      *(outbuffer + offset + 0) = (u_az.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_az.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->az);
      union {
        int16_t real;
        uint16_t base;
      } u_gx;
      u_gx.real = this->gx;
      *(outbuffer + offset + 0) = (u_gx.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gx.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->gx);
      union {
        int16_t real;
        uint16_t base;
      } u_gy;
      u_gy.real = this->gy;
      *(outbuffer + offset + 0) = (u_gy.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gy.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->gy);
      union {
        int16_t real;
        uint16_t base;
      } u_gz;
      u_gz.real = this->gz;
      *(outbuffer + offset + 0) = (u_gz.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gz.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->gz);
      union {
        float real;
        uint32_t base;
      } u_qw;
      u_qw.real = this->qw;
      *(outbuffer + offset + 0) = (u_qw.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_qw.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_qw.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_qw.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->qw);
      union {
        float real;
        uint32_t base;
      } u_qx;
      u_qx.real = this->qx;
      *(outbuffer + offset + 0) = (u_qx.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_qx.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_qx.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_qx.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->qx);
      union {
        float real;
        uint32_t base;
      } u_qy;
      u_qy.real = this->qy;
      *(outbuffer + offset + 0) = (u_qy.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_qy.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_qy.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_qy.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->qy);
      union {
        float real;
        uint32_t base;
      } u_qz;
      u_qz.real = this->qz;
      *(outbuffer + offset + 0) = (u_qz.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_qz.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_qz.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_qz.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->qz);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int32_t real;
        uint32_t base;
      } u_left_count;
      u_left_count.base = 0;
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->left_count = u_left_count.real;
      offset += sizeof(this->left_count);
      union {
        int32_t real;
        uint32_t base;
      } u_right_count;
      u_right_count.base = 0;
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->right_count = u_right_count.real;
      offset += sizeof(this->right_count);
      this->sonic_distance_time =  ((uint16_t) (*(inbuffer + offset)));
      this->sonic_distance_time |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->sonic_distance_time);
      union {
        int16_t real;
        uint16_t base;
      } u_ax;
      u_ax.base = 0;
      u_ax.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_ax.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->ax = u_ax.real;
      offset += sizeof(this->ax);
      union {
        int16_t real;
        uint16_t base;
      } u_ay;
      u_ay.base = 0;
      u_ay.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_ay.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->ay = u_ay.real;
      offset += sizeof(this->ay);
      union {
        int16_t real;
        uint16_t base;
      } u_az;
      u_az.base = 0;
      u_az.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_az.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->az = u_az.real;
      offset += sizeof(this->az);
      union {
        int16_t real;
        uint16_t base;
      } u_gx;
      u_gx.base = 0;
      u_gx.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gx.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->gx = u_gx.real;
      offset += sizeof(this->gx);
      union {
        int16_t real;
        uint16_t base;
      } u_gy;
      u_gy.base = 0;
      u_gy.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gy.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->gy = u_gy.real;
      offset += sizeof(this->gy);
      union {
        int16_t real;
        uint16_t base;
      } u_gz;
      u_gz.base = 0;
      u_gz.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gz.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->gz = u_gz.real;
      offset += sizeof(this->gz);
      union {
        float real;
        uint32_t base;
      } u_qw;
      u_qw.base = 0;
      u_qw.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_qw.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_qw.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_qw.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->qw = u_qw.real;
      offset += sizeof(this->qw);
      union {
        float real;
        uint32_t base;
      } u_qx;
      u_qx.base = 0;
      u_qx.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_qx.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_qx.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_qx.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->qx = u_qx.real;
      offset += sizeof(this->qx);
      union {
        float real;
        uint32_t base;
      } u_qy;
      u_qy.base = 0;
      u_qy.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_qy.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_qy.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_qy.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->qy = u_qy.real;
      offset += sizeof(this->qy);
      union {
        float real;
        uint32_t base;
      } u_qz;
      u_qz.base = 0;
      u_qz.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_qz.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_qz.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_qz.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->qz = u_qz.real;
      offset += sizeof(this->qz);
     return offset;
    }

    const char * getType(){ return "candynamix_msgs/sensor"; };
    const char * getMD5(){ return "c80bbef27a4128c9df71420239c980f0"; };

  };

}
#endif