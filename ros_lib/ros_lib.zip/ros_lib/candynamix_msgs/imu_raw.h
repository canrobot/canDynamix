#ifndef _ROS_candynamix_msgs_imu_raw_h
#define _ROS_candynamix_msgs_imu_raw_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace candynamix_msgs
{

  class imu_raw : public ros::Msg
  {
    public:
      typedef int16_t _a_fsr_type;
      _a_fsr_type a_fsr;
      typedef int16_t _g_fsr_type;
      _g_fsr_type g_fsr;
      typedef int16_t _ax_type;
      _ax_type ax;
      typedef int16_t _ay_type;
      _ay_type ay;
      typedef int16_t _az_type;
      _az_type az;
      typedef int16_t _gx_type;
      _gx_type gx;
      typedef int16_t _gy_type;
      _gy_type gy;
      typedef int16_t _gz_type;
      _gz_type gz;

    imu_raw():
      a_fsr(0),
      g_fsr(0),
      ax(0),
      ay(0),
      az(0),
      gx(0),
      gy(0),
      gz(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int16_t real;
        uint16_t base;
      } u_a_fsr;
      u_a_fsr.real = this->a_fsr;
      *(outbuffer + offset + 0) = (u_a_fsr.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_a_fsr.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->a_fsr);
      union {
        int16_t real;
        uint16_t base;
      } u_g_fsr;
      u_g_fsr.real = this->g_fsr;
      *(outbuffer + offset + 0) = (u_g_fsr.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_g_fsr.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->g_fsr);
      union {
        int16_t real;
        uint16_t base;
      } u_ax;
      u_ax.real = this->ax;
      *(outbuffer + offset + 0) = (u_ax.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ax.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->ax);
      union {
        int16_t real;
        uint16_t base;
      } u_ay;
      u_ay.real = this->ay;
      *(outbuffer + offset + 0) = (u_ay.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ay.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->ay);
      union {
        int16_t real;
        uint16_t base;
      } u_az;
      u_az.real = this->az;
      *(outbuffer + offset + 0) = (u_az.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_az.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->az);
      union {
        int16_t real;
        uint16_t base;
      } u_gx;
      u_gx.real = this->gx;
      *(outbuffer + offset + 0) = (u_gx.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gx.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->gx);
      union {
        int16_t real;
        uint16_t base;
      } u_gy;
      u_gy.real = this->gy;
      *(outbuffer + offset + 0) = (u_gy.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gy.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->gy);
      union {
        int16_t real;
        uint16_t base;
      } u_gz;
      u_gz.real = this->gz;
      *(outbuffer + offset + 0) = (u_gz.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gz.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->gz);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int16_t real;
        uint16_t base;
      } u_a_fsr;
      u_a_fsr.base = 0;
      u_a_fsr.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_a_fsr.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->a_fsr = u_a_fsr.real;
      offset += sizeof(this->a_fsr);
      union {
        int16_t real;
        uint16_t base;
      } u_g_fsr;
      u_g_fsr.base = 0;
      u_g_fsr.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_g_fsr.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->g_fsr = u_g_fsr.real;
      offset += sizeof(this->g_fsr);
      union {
        int16_t real;
        uint16_t base;
      } u_ax;
      u_ax.base = 0;
      u_ax.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_ax.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->ax = u_ax.real;
      offset += sizeof(this->ax);
      union {
        int16_t real;
        uint16_t base;
      } u_ay;
      u_ay.base = 0;
      u_ay.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_ay.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->ay = u_ay.real;
      offset += sizeof(this->ay);
      union {
        int16_t real;
        uint16_t base;
      } u_az;
      u_az.base = 0;
      u_az.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_az.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->az = u_az.real;
      offset += sizeof(this->az);
      union {
        int16_t real;
        uint16_t base;
      } u_gx;
      u_gx.base = 0;
      u_gx.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gx.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->gx = u_gx.real;
      offset += sizeof(this->gx);
      union {
        int16_t real;
        uint16_t base;
      } u_gy;
      u_gy.base = 0;
      u_gy.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gy.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->gy = u_gy.real;
      offset += sizeof(this->gy);
      union {
        int16_t real;
        uint16_t base;
      } u_gz;
      u_gz.base = 0;
      u_gz.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gz.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->gz = u_gz.real;
      offset += sizeof(this->gz);
     return offset;
    }

    const char * getType(){ return "candynamix_msgs/imu_raw"; };
    const char * getMD5(){ return "350ba12955054fb76c1e06facf46577c"; };

  };

}
#endif