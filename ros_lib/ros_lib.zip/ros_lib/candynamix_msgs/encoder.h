#ifndef _ROS_candynamix_msgs_encoder_h
#define _ROS_candynamix_msgs_encoder_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace candynamix_msgs
{

  class encoder : public ros::Msg
  {
    public:
      typedef int32_t _left_count_type;
      _left_count_type left_count;
      typedef int32_t _right_count_type;
      _right_count_type right_count;

    encoder():
      left_count(0),
      right_count(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int32_t real;
        uint32_t base;
      } u_left_count;
      u_left_count.real = this->left_count;
      *(outbuffer + offset + 0) = (u_left_count.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_left_count.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_left_count.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_left_count.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->left_count);
      union {
        int32_t real;
        uint32_t base;
      } u_right_count;
      u_right_count.real = this->right_count;
      *(outbuffer + offset + 0) = (u_right_count.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_right_count.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_right_count.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_right_count.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->right_count);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int32_t real;
        uint32_t base;
      } u_left_count;
      u_left_count.base = 0;
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_left_count.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->left_count = u_left_count.real;
      offset += sizeof(this->left_count);
      union {
        int32_t real;
        uint32_t base;
      } u_right_count;
      u_right_count.base = 0;
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_right_count.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->right_count = u_right_count.real;
      offset += sizeof(this->right_count);
     return offset;
    }

    const char * getType(){ return "candynamix_msgs/encoder"; };
    const char * getMD5(){ return "cfe01b0ebac2ef6f85c56def8b6961cd"; };

  };

}
#endif